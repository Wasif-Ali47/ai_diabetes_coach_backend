import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import { startReminderPushScheduler } from './services/reminderPushScheduler.js';
import { ensureFirebaseAdmin } from './utils/firebaseAdminInit.js';

// Load environment variables
dotenv.config();

const app = express();

// Middleware
// Global request logger to see every incoming request
app.use((req, res, next) => {
  const start = Date.now();
  console.log(`➡️  ${req.method} ${req.originalUrl}`);
  if (Object.keys(req.body || {}).length > 0) {
    console.log('   Body:', JSON.stringify(req.body, null, 2));
  }
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`⬅️  ${req.method} ${req.originalUrl} ${res.statusCode} (${duration} ms)`);
  });
  next();
});



const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) return callback(null, true);
    
    const allowedOrigins = [
      'https://adminnutriguide.vercel.app',
      'http://localhost:3000',
      'http://localhost:3001',
      'http://127.0.0.1:3000',
      'http://127.0.0.1:3001',
    ];
    
    if (allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(null, true); // Allow all for development - restrict in production
    }
  },
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  credentials: true,
};

app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import mealPlanRoutes from './routes/mealPlans.js';
import symptomRoutes from './routes/symptoms.js';
import reminderRoutes from './routes/reminders.js';
import doctorRoutes from './routes/doctors.js';
import chatRoutes from './routes/chat.js';
import notificationRoutes from './routes/notifications.js';
import adminRoutes from './routes/admin.js';
import adminAuthRoutes from './routes/adminAuth.js';
import foodRoutes from './routes/food.js';
import activityRoutes from './routes/activity.js';
import progressRoutes from './routes/progress.js';
import exportRoutes from './routes/export.js';

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/meal-plans', mealPlanRoutes);
app.use('/api/symptoms', symptomRoutes);
app.use('/api/reminders', reminderRoutes);
app.use('/api/doctors', doctorRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/food', foodRoutes);
app.use('/api/activity', activityRoutes);
app.use('/api/progress', progressRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/admin/auth', adminAuthRoutes);
app.use('/api/admin', adminRoutes);

// Log registered admin routes on startup
console.log('📋 Admin routes registered:');
console.log('   GET  /api/admin/test');
console.log('   GET  /api/admin/users');
console.log('   GET  /api/admin/meal-plans');
console.log('   POST /api/admin/notifications/broadcast');

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'NutriGuide API is running',
    timestamp: new Date().toISOString()
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found'
  });
});

// Connect to MongoDB
const MONGODB_URI = process.env.MONGODB_URI || "mongodb+srv://yasirkh261:yasirkh261@cluster0.yhwramo.mongodb.net/nutriguide?retryWrites=true&w=majority&appName=Cluster0"
const PORT = process.env.PORT || 5027;

mongoose.connect(MONGODB_URI)
  .then(() => {
    console.log('✅ Connected to MongoDB');
    const fb = ensureFirebaseAdmin();
    console.log('[reminderPush] Firebase Admin at startup:', fb ? 'ready (FCM can send)' : 'missing credentials (reminder pushes will not send)');
    startReminderPushScheduler();
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📡 API available at http://localhost:${PORT}/api`);
    });
  })
  .catch((error) => {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  });

export default app;
