import User from '../models/User.js';
import { validationResult } from 'express-validator';

/**
 * Get current user profile
 */
export const getProfile = async (req, res) => {
  try {
    console.log('[getProfile] Request received for userId:', req.userId);
    const user = await User.findById(req.userId).select('-password');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get profile',
      error: error.message
    });
  }
};

/**
 * Update personal info
 */
export const updatePersonalInfo = async (req, res) => {
  try {
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('[updatePersonalInfo] ❌ Validation errors:', errors.array());
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: errors.array()
      });
    }

    const { firstName, lastName, email, dateOfBirth, biologicalSex } = req.body;
    const updateData = {};

    if (firstName !== undefined) updateData.firstName = firstName;
    if (lastName !== undefined) updateData.lastName = lastName;
    if (email !== undefined) updateData.email = email;
    if (dateOfBirth !== undefined) updateData.dateOfBirth = dateOfBirth;
    if (biologicalSex !== undefined) updateData.biologicalSex = biologicalSex;


    const user = await User.findByIdAndUpdate(
      req.userId,
      updateData,
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }


    res.json({
      success: true,
      message: 'Personal info updated successfully',
      user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update personal info',
      error: error.message
    });
  }
};

/**
 * Update body info
 */
export const updateBodyInfo = async (req, res) => {
  try {
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('[updateBodyInfo] ❌ Validation errors:', errors.array());
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: errors.array()
      });
    }

    const { heightFeet, heightInches, heightCm, weight, activityLevel } = req.body;
    const updateData = {};

    // Handle height: either feet/inches OR cm
    if (heightCm !== undefined) {
      // User provided height in cm
      updateData.height = {
        cm: parseFloat(heightCm)
      };
    } else if (heightFeet !== undefined || heightInches !== undefined) {
      // User provided height in feet/inches
      updateData.height = {
        feet: heightFeet !== undefined ? parseInt(heightFeet) : 0,
        inches: heightInches !== undefined ? parseInt(heightInches) : 0
      };
    }
    if (weight !== undefined) updateData.weight = weight;
    if (activityLevel !== undefined) updateData.activityLevel = activityLevel;


    const user = await User.findByIdAndUpdate(
      req.userId,
      updateData,
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }


    res.json({
      success: true,
      message: 'Body info updated successfully',
      user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update body info',
      error: error.message
    });
  }
};

/**
 * Update health conditions
 */
export const updateHealthConditions = async (req, res) => {
  try {
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: errors.array()
      });
    }

    const { healthConditions, medications } = req.body;
    const updateData = {};

    if (healthConditions !== undefined) updateData.healthConditions = healthConditions;
    if (medications !== undefined) updateData.medications = medications;


    const user = await User.findByIdAndUpdate(
      req.userId,
      updateData,
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }


    res.json({
      success: true,
      message: 'Health profile updated successfully',
      user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update health profile',
      error: error.message
    });
  }
};

/**
 * Update diet preferences
 */
export const updateDietPreferences = async (req, res) => {
  try {
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('[updateDietPreferences] ❌ Validation errors:', errors.array());
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: errors.array()
      });
    }

    const { dietPreferences } = req.body;


    const user = await User.findByIdAndUpdate(
      req.userId,
      { dietPreferences: dietPreferences || {} },
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }


    res.json({
      success: true,
      message: 'Diet preferences updated successfully',
      user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update diet preferences',
      error: error.message
    });
  }
};

/**
 * Update settings
 */
export const updateSettings = async (req, res) => {
  try {
    const { settings } = req.body;

    const user = await User.findByIdAndUpdate(
      req.userId,
      { settings: settings || {} },
      { new: true, runValidators: true }
    ).select('-password');

    res.json({
      success: true,
      message: 'Settings updated successfully',
      user
    });
  } catch (error) {
    console.error('Update settings error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update settings',
      error: error.message
    });
  }
};

/**
 * Complete onboarding
 */
export const completeOnboarding = async (req, res) => {
  try {

    const user = await User.findByIdAndUpdate(
      req.userId,
      { onboardingComplete: true },
      { new: true }
    ).select('-password');

    if (!user) {
      console.log('[completeOnboarding] ❌ User not found:', req.userId);
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }


    res.json({
      success: true,
      message: 'Onboarding completed',
      user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to complete onboarding',
      error: error.message
    });
  }
};

/**
 * Delete account
 */
export const deleteAccount = async (req, res) => {
  try {
    await User.findByIdAndDelete(req.userId);
    res.json({
      success: true,
      message: 'Account deleted successfully'
    });
  } catch (error) {
    console.error('Delete account error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete account',
      error: error.message
    });
  }
};
